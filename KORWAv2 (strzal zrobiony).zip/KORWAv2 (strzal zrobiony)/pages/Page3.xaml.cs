﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pages
{
    /// <summary>
    /// Interaction logic for Page3.xaml
    /// </summary>
    public partial class Page3 : Page
    {
        public Page3()
        {
            InitializeComponent();
        }

        public void BTN_Strzal_Click(object sender, RoutedEventArgs e)
        {
            Wyniklos.Items.Clear();
            string[] alko = new string[] {"Harnaś", "Halne", "Kuflowe Mocne", "Perła Export", "Perła Chmielowa", "Żywiec", "Tyskie", "Imperator", "Redds Malinowy" , "Kustosz Mocne", "Kustosz Tequila", "Warka", "Romper", "Desperados", "Lech", "Łomża", "Specjal", "Piast", "Żubr", "Tatra" , "Zatecky", "Carlsberg", "Heineken", "Żubrówka", "Bocian", "Lubelska", "Soplica", "Amundsen", "Luksusowa", "Stock", "Smirnoff", "Wyborowa", "Stumbras" };

            string[] wyzwanie = new string[]
            {"Zeruj!", "Walnij z leja!", "Zagraj nim we flanki!", "Napij się ze swoim najlepszym przyjacielem!", "Wypij na leżąco!", "Wypij do góry nogami!","Wypij w plenerze!","Wypij z nietypowego naczynia!", "Zagryź kiszonym ogórkiem!","Zagryź śledziem!" };

            Random los = new Random();

            string losoweAlko = alko[los.Next(alko.Length)];
            string losoweWyzwanie = wyzwanie[los.Next(wyzwanie.Length)];

            Wyniklos.Items.Add( $"Twój wylosowany alkohol na dziś to: {losoweAlko}");
            Wyniklos.Items.Add($"Twoje wyzwanie z wylosowanym alkoholem to: {losoweWyzwanie}");
           

            
        }
    }
}
