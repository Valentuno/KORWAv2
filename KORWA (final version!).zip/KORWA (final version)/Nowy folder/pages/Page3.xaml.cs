﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.IO; // Dodajemy przestrzeń nazw System.IO, aby móc używać klasy StreamWriter

namespace pages
{
    
    public partial class Page3 : Page 
    {
        public Page3()
        {
            InitializeComponent();
        }

        // Metoda obsługująca kliknięcie przycisku "Los"
        public void BTN_Strzal_Click(object sender, RoutedEventArgs e)
        {
            // Czyszczenie list boxa "Wyniklos"
            Wyniklos.Items.Clear();

            // Tablica zawierająca dostępne alkohole
            string[] alko = new string[] { "Harnaś", "Halne", "Kuflowe Mocne", "Perła Export", "Perła Chmielowa", "Żywiec", "Tyskie", "Imperator", "Redds Malinowy", "Kustosz Mocne", "Kustosz Tequila", "Warka", "Romper", "Desperados", "Lech", "Łomża", "Specjal", "Piast", "Żubr", "Tatra", "Zatecky", "Carlsberg", "Heineken", "Żubrówka", "Bocian", "Lubelska", "Soplica", "Amundsen", "Luksusowa", "Stock", "Smirnoff", "Wyborowa", "Stumbras" };

            // Tablica zawierająca dostępne wyzwania
            string[] wyzwanie = new string[]
            {"Zeruj!", "Walnij z leja!", "Zagraj nim we flanki!", "Napij się ze swoim najlepszym przyjacielem!", "Wypij na leżąco!", "Wypij do góry nogami!","Wypij w plenerze!","Wypij z nietypowego naczynia!", "Zagryź kiszonym ogórkiem!","Zagryź śledziem!" };

            // Zainicjowanie generatora liczb losowych
            Random los = new Random();

            // Losowanie alkoholu i wyzwania 
            string losoweAlko = alko[los.Next(alko.Length)];
            string losoweWyzwanie = wyzwanie[los.Next(wyzwanie.Length)]; // użyto metody .Lenght która zwraca ilość elementów w tablicy, aby móc losować dany element z tabilcy alko lub wyzwanie

            // Dodawanie wylosowanych danych do list boxa "Wyniklos"
            Wyniklos.Items.Add($"Twój wylosowany alkohol na dziś to: {losoweAlko}");
            Wyniklos.Items.Add($"Twoje wyzwanie z wylosowanym alkoholem to: {losoweWyzwanie}");

            // Ścieżka do pliku tekstowego
            string sciezka = "historia.txt";

            try
            {
                // Zapisywanie wylosowanego alkoholu i wyzwania do pliku "historia.txt"
                using (StreamWriter zapis = new StreamWriter(sciezka, true)) //dodałem metode using, która zapewnia że strumienie zostaną poprawnie zamknięte po zakończeniu operacji a true sprawia że plik będzie nadpisywany a nie zastępywany innym tekstem
                {
                    zapis.WriteLine($"Wylosowany alkohol: {losoweAlko}");
                    zapis.WriteLine($"Wyzwanie: {losoweWyzwanie}"); //to będzie wyświetlane po zapisie w "historia.txt"
                    zapis.WriteLine(); // zastosowano aby był odstęp kiedy zapiszemy kolejne losowanie alko i wyzwania
                }

                // Wyświetlanie informacji o powodzeniu programu wraz z interfejsem o charakterze informacyjnym i przyciskiem do zatwierdzania "ok"
                MessageBox.Show("Wylosowany alkohol i wyzwanie zostały zapisane do pliku historia.txt", "Udało się!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex) // zmienna ex przypisana do funkcji, ma za zadanie wyłapywać błedy podczas próby zapisu
            {
                // Wyświetlanie informacji o błędzie programu wraz z interfejsem o charakterze informacyjnym (error) i przyciskiem do zatwierdzania "ok"
                MessageBox.Show($"Wystąpił błąd podczas zapisywania pliku: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        // Metoda obsługująca naciśnięcie przycisku "Wyświetl historię"
        private void BTNhistoria_Click(object sender, RoutedEventArgs e)
        {
            string sciezka = "historia.txt"; //ponowna inicjalizacja ścieżki
            Wyniklos.Items.Clear(); // Czyszczenie listboxa
            try
            {
                // Otwarcie pliku historia.txt do odczytu
                StreamReader odczyt = new StreamReader(sciezka);

                // Odczytanie treści z pliku i dodanie ich do listboxa Wyniklos
                string tresc;
                while ((tresc = odczyt.ReadLine()) != null) // w tym miejscu wykonuje się pętla która przechodzi po tekście z pliku linijka po linijce i przypisuje niepuste linijki do zmiennej tresc a następnie do listboxa "Wyniklos"
                {//pętla działa dopóki odczytywana linia jest różna od null czyli od zera
                    Wyniklos.Items.Add(tresc);
                }

                // Zamknięcie pliku historia.txt
                odczyt.Close();
            }
            catch (Exception ex) // znów obsługa błędu, tym razem w przypadku błedu odczytu
            {
                MessageBox.Show($"Wystąpił błąd podczas odczytywania pliku: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        // Metoda obsługująca naciśnięcie przycisku "Wyczyść"
        private void BTNczysc_Click(object sender, RoutedEventArgs e)
        {
            Wyniklos.Items.Clear(); // znowu czyszczenie listboxa
        }
    }
}
