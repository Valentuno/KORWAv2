﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pages
{
    /// <summary>
    /// Interaction logic for Page2.xaml
    /// </summary>
    public partial class Page2 : Page
    {// Tworzenie tablicy obiektów typu Alkohol
        public Alkohol[] alkohols = new Alkohol[]

        // Inicjalizacja obiektów typu Alkohol za pomocą konstruktora

        {
        new Alkohol(0,"Desperados","4,37g/zl","6,78"),
        new Alkohol(1,"Heineken","5,83g/zl","6,71"),
        new Alkohol(2,"Zatecky","7,62g/zl","6,34"),
        new Alkohol(3,"Perła export","7,47g/zl","6,3"),
        new Alkohol(4,"Carlseberg","5,71g/zl","6,22"),
        new Alkohol(5,"Lech","6,28g/zl","6,21"),
        new Alkohol(6,"Łomża","7,54g/zl","6,10"),
        new Alkohol(7,"Redds Malina","4,8g/zl","6,03"),
        new Alkohol(8,"Perła chmiel","8,62g/zl","5,47"),
        new Alkohol(9,"Tyskie","7,47g/zl","5,41"),
        new Alkohol(10,"Harnas","11,17g/zl","5,34"),
        new Alkohol(11,"Warka","7,47g/zl","5,17"),
        new Alkohol(12,"Żubr","10,07g/zl","4,79"),
        new Alkohol(13,"Piast","6,91g/zl","4,70"),
        new Alkohol(14,"Specjal","10,94g/zl","4,59"),
        new Alkohol(15,"Tatra","8,51g/zl","4,17"),
        new Alkohol(16,"Kustosz mocne","12,63g/zl","3,84"),
        };

        public Page2()
        {
            InitializeComponent();

            // Przypisanie tablicy alkohols do źródła danych kontrolki Mylist

            Mylist.ItemsSource = alkohols;
            
        }
    }
}
