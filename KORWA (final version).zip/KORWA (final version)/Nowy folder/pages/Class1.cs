﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pages
{
    public class Alkohol //tworzenie nowej klasy Alkohol
    {
        public int AlkoholId { get; set; } //definiowanie numeru alkoholu
        public string Title { get; set; } //definiowanie nazwy
        public string Rent { get; set; } // definiowanie rentownosci
        public string Ocena { get; set; } // definiowanie oceny


        public Alkohol(int alkoholid, string title, string rent, string ocena) //metoda tworzaca nowe obiekty klasy Alkohol
        {
            Title = title;
            Rent = rent;
            Ocena = ocena;
            AlkoholId = alkoholid;
            
        }
    }
}
