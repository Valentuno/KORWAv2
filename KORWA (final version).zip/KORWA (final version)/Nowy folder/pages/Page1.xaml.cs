﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pages
{
    /// <summary>
    /// Interaction logic for Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        public Page1()
        {
            InitializeComponent();
        }

        // Obsługa kliknięcia przycisku "kalkulaotr_button"
        private void kalkulaotr_button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Konwersja wartości tekstowych na liczby
                double pojemnosc = Convert.ToDouble(pojemnosc_box.Text);
                double procent = Convert.ToDouble(procent_box.Text);
                double cena = Convert.ToDouble(cena_box.Text);

                // Sprawdzanie warunków i wyrzucanie wyjątków w przypadku błędnych wartości
                if (pojemnosc < 1)
                {
                    throw new ArgumentException("z pustego to nawet Salomon nie naleje");
                }
                if (pojemnosc > 480000)
                {
                    throw new ArgumentException("Przed wypiciem takiej ilości skontaktuj się z lekarzem lub farmaceutą");
                }
                if (procent > 100)
                {
                    throw new ArgumentException("co ty walisz, paliwo rakietowe?");
                }
                if (procent < 0.01)
                {
                    throw new ArgumentException("bezalkoholowe? nie bądź miękka faja");
                }
                if (cena < 0.01)
                {
                    throw new ArgumentException("gratis to uczciwa cena");
                }
                else
                {
                    // Obliczanie wyników i przypisywanie ich do odpowiednich pól tekstowych
                    double etanol = Math.Round(pojemnosc * (procent / 100), 2);
                    etanol_box.Text = Convert.ToString(etanol);

                    double koszt = Math.Round(etanol / cena, 2);
                    zl_box.Text = Convert.ToString(koszt);
                }
            }
            catch (FormatException)
            {
                // Obsługa wyjątku w przypadku błędnego formatu danych
                MessageBox.Show("Błędny format podanych wartości", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (ArgumentException ex)
            {
                // Obsługa wyjątku z wyrzuconą wiadomością błędu
                MessageBox.Show(ex.Message, "Błąd", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        // Obsługa kliknięcia przycisku "wyczyść"
        private void wyczyść_Click(object sender, RoutedEventArgs e)
        {
            // Czyszczenie pól tekstowych
            pojemnosc_box.Clear();
            procent_box.Clear();
            cena_box.Clear();
            zl_box.Clear();
            etanol_box.Clear();
        }
    }
}
